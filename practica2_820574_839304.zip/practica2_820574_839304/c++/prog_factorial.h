#pragma once
#include "programa.h"

using namespace std;

/*
* Clase heredada de Programa
* Ejecuta una serie de instrucciones que muestran por pantalla el
* factorial del numero introducido por el usuario
*/
class Prog_Factorial : public Programa
{        
    public:
        Prog_Factorial();
};
