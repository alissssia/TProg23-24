#pragma once
#include "programa.h"

using namespace std;

/* 
* Clase heredada de Programa
* Ejecuta una serie de instrucciones que muestran por pantalla la
* suma de dos numeros introducidos por el usuario
*/
class Prog_Cuenta_Atras : public Programa
{        
    public:
        Prog_Cuenta_Atras();
};
