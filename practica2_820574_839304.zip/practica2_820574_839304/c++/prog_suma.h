#pragma once
#include "programa.h"

using namespace std;

/* 
* Clase heredada de Programa
* Ejecuta una serie de instrucciones que muestran por pantalla la
* suma de dos numeros introducidos por el usuario
*/
class Prog_Suma : public Programa
{        
    public:
        Prog_Suma();
};
