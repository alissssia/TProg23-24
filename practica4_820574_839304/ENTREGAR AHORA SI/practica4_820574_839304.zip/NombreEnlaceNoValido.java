/*
* Fichero: NombreEnlaceNoValido.java
* Autores: Alicia Lazaro Huerta y Manel Jorda Puig Rubio
* Fecha: 25/03/2024
*/

public class NombreEnlaceNoValido extends ExcepcionNombreObjeto
{
    public NombreEnlaceNoValido(String message)
    {
        super(message);
    }
}