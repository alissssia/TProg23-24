/*
* Fichero: NombreRutaNoValido.java
* Autores: Alicia Lazaro Huerta y Manel Jorda Puig Rubio
* Fecha: 14/04/2024
*/

public class NombreRutaNoValido extends ExcepcionNombreObjeto
{
    public NombreRutaNoValido(String message)
    {
        super(message);
    }
}