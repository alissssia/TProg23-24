/*
* Fichero: ExcepcionTipoNodo.java
* Autores: Alicia Lazaro Huerta y Manel Jorda Puig Rubio
* Fecha: 15/04/2024
*/

public class ExcepcionTipoObjeto extends ExcepcionArbolFicheros
{
    public ExcepcionTipoObjeto(String message)
    {
        super(message);
    }
}