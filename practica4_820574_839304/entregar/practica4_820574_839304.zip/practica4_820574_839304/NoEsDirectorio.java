/*
* Fichero: NoEsDirectorio.java
* Autores: Alicia Lazaro Huerta y Manel Jorda Puig Rubio
* Fecha: 25/03/2024
*/

public class NoEsDirectorio extends ExcepcionTipoObjeto
{
    public NoEsDirectorio(String message)
    {
        super(message);
    }
}