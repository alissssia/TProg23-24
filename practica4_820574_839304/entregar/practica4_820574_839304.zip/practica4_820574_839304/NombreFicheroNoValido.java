/*
* Fichero: NombreFicheroNoValido.java
* Autores: Alicia Lazaro Huerta y Manel Jorda Puig Rubio
* Fecha: 14/04/2024
*/

public class NombreFicheroNoValido extends ExcepcionNombreObjeto
{
    public NombreFicheroNoValido(String message)
    {
        super(message);
    }
}
