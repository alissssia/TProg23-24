/*
* Fichero: ExcepcionRuta.java
* Autores: Alicia Lazaro Huerta y Manel Jorda Puig Rubio
* Fecha: 25/03/2024
*/

public class ExcepcionRuta extends ExcepcionArbolFicheros
{
    public ExcepcionRuta(String message)
    {
        super(message);
    }
}