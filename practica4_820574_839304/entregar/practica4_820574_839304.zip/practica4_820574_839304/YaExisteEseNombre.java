/*
* Fichero: YaExisteEseNombre.java
* Autores: Alicia Lazaro Huerta y Manel Jorda Puig Rubio
* Fecha: 25/03/2024
*/

public class YaExisteEseNombre extends ExcepcionNombreObjeto
{
    public YaExisteEseNombre(String message)
    {
        super(message);
    }
}