/*
* Fichero: ExcepcionNombreObjeto.java
* Autores: Alicia Lazaro Huerta y Manel Jorda Puig Rubio
* Fecha: 25/03/2024
*/

public class ExcepcionNombreObjeto extends ExcepcionArbolFicheros
{
    public ExcepcionNombreObjeto(String message)
    {
        super(message);
    }
}