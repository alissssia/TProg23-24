/*
* Fichero: NoEsFichero.java
* Autores: Alicia Lazaro Huerta y Manel Jorda Puig Rubio
* Fecha: 15/04/2024
*/

public class NoEsFichero extends ExcepcionTipoObjeto
{
    public NoEsFichero(String message)
    {
        super(message);
    }
}