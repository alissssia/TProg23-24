#pragma once

#include "camion.h"
#include "carga.h"
#include "contenedor.h"
#include "deposito.h"
#include "inventario.h"
#include "prodgenerico.h"
#include "producto.h"
#include "servivo.h"
#include "toxico.h"
#include <iostream>